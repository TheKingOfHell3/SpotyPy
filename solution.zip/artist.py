class Artist:

    def __init__(self, firstName, lastName, birthYear, albums, singles):
        self.__firstName = firstName
        self.__lastName = lastName
        self.__birthYear = birthYear
        self.__albums = albums
        self.__singles = singles

    def getFirstName(self):
        return self.__firstName

    def getSecondName(self):
        return self.__lastName

    def getBirthYear(self):
        return self.__birthYear

    def getAlbums(self):
        return self.__albums

    def getSingle(self):
        return self.__singles

    def mostLikedSong(self):
        array_with_likes = []
        array_with_songs = []
        answer = None
        for elements in self.getAlbums():
            for elements1 in elements.getSongs():
                array_with_songs.append(elements1)
                array_with_likes.append(elements1.getLikes())
        for elements in self.getSingle():
            array_with_songs.append(elements)
            array_with_likes.append(elements.getLikes())

        for elements in array_with_songs:
            if elements.getLikes() == max(array_with_likes):
                answer = elements

        return answer

    def leastLikedSong(self):
        array_with_likes = []
        array_with_songs = []
        answer = None
        for elements in self.getAlbums():
            for elements1 in elements.getSongs():
                array_with_songs.append(elements1)
                array_with_likes.append(elements1.getLikes())
        for elements in self.getSingle():
            array_with_songs.append(elements)
            array_with_likes.append(elements.getLikes())

        for elements in array_with_songs:
            if elements.getLikes() == min(array_with_likes):
                answer = elements

        return answer

    def totalLikes(self):
        counter = 0
        for elements in self.getAlbums():
            for elements1 in elements.getSongs():
                counter = counter + elements1.getLikes()
        for elements in self.getSingle():
            counter = counter + elements.getLikes()

        return counter

    def __str__(self):
        return f'Name: {self.getFirstName()} {self.getSecondName()},Birth year:{self.getBirthYear()},Total likes:{self.totalLikes()}'

    @classmethod
    def two_artist_equal(cls, artist1, artist2):
        if (artist1.getFirstName() == artist2.getFirstName()) and (
                artist1.getSecondName() == artist2.getSecondName()) and (
                artist1.getBirthYear() == artist2.getBirthYear()):
            return True
