class Song:
    def __init__(self, title, releaseYear, duration=60, likes=0):
        self.__title = title
        self.__releaseYear = releaseYear
        self.__duration = duration
        self.__likes = likes

    def getTitle(self):
        return self.__title

    def getReleaseYear(self):
        return self.__releaseYear

    def getDuration(self):
        return self.__duration

    def getLikes(self):
        return self.__likes

    def setDuration(self, new_duration):
        if (new_duration < 0) or (new_duration > 720) or new_duration == self.__duration:
            return False
        else:
            self.__duration = new_duration
            return True

    def like(self):
        self.__likes = self.__likes + 1

    def unlike(self):
        self.__likes = self.__likes - 1

    def __str__(self):
        return f'Title:{self.getTitle()},Duration:{(self.getDuration() % 60)} minutes,Release year:{self.getReleaseYear()},Likes:{self.getLikes()}'

    @classmethod
    def twoSongsEqual(cls, song1, song2):
        if (song1.getTitle() == song2.getTitle()) and (song1.getReleaseYear() == song2.getReleaseYear()) and (
                song1.getDuration() == song2.getDuration()):
            return True


