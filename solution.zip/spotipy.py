from artist import Artist


class SpotiPy:

    def __init__(self):
        self.__artists = []

    def getArtists(self):
        return self.__artists

    def addArtists(self, *args):
        for elements in args:
            test_int = 0
            for elements1 in self.getArtists():
                if Artist.two_artist_equal(elements, elements1):
                    test_int = test_int + 1
            if test_int == 0:
                self.__artists.append(elements)

    def getTopTrendingArtist(self):
        array_with_likes = []
        answer_artist = None
        for elements in self.getArtists():
            array_with_likes.append(elements.totalLikes())
        for elements in self.getArtists():
            if elements.totalLikes() == max(array_with_likes):
                answer_artist = elements
        answer = (answer_artist.getFirstName(), answer_artist.getSecondName())
        return answer

    def getTopTrendingAlbum(self):
        array_with_likes = []
        answer_album = None
        for elements in self.getArtists():
            for elements1 in elements.getAlbums():
                array_with_likes.append(elements1.all_likes())
        for elements in self.getArtists():
            for elements1 in elements.getAlbums():
                if elements1.all_likes() == max(array_with_likes):
                    answer_album = elements1

        return answer_album.getTitle()

    def getTopTrendingSong(self):
        array_most_liked_songs = []
        array_with_likes = []
        answer_song = None
        for elements in self.getArtists():
            array_most_liked_songs.append(elements.mostLikedSong())
        for elements in array_most_liked_songs:
            array_with_likes.append(elements.getLikes())
        for elements in array_most_liked_songs:
            if elements.getLikes() == max(array_with_likes):
                answer_song = elements

        return answer_song.getTitle()
