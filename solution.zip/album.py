from song import Song


class Album:
    def __init__(self, title, releaseYear):
        self.__title = title
        self.__releaseYear = releaseYear
        self.__songs = []

    def getTitle(self):
        return self.__title

    def getReleaseYear(self):
        return self.__releaseYear

    def getSongs(self):
        return self.__songs

    def addSong(self, *args):
        counter = 0
        for elements in args:
            test_int = 0
            for elements1 in self.getSongs():
                if Song.twoSongsEqual(elements, elements1) == True:
                    test_int = test_int + 1
            if test_int == 0:
                self.__songs.append(elements)
                counter = counter + 1
        return counter

    def sortBy(self, byKey, reverse):
        return sorted(self.getSongs(), key=byKey, reverse=reverse)

    def sortByName(self, reverse):
        return self.sortBy(byKey=lambda song: song.getTitle().lower(), reverse=reverse)

    def sortByPopularity(self, reverse):
        return self.sortBy(byKey=lambda song: song.getLikes(), reverse=reverse)

    def sortByDuration(self, reverse):
        return self.sortBy(byKey=lambda song: song.getDuration(), reverse=reverse)

    def sortByReleaseYear(self, reverse):
        return self.sortBy(byKey=lambda song: song.getReleaseYear(), reverse=reverse)

    def __str__(self):
        test_str = f'Title:{self.getTitle()},Release year:{self.getReleaseYear()},songs:' + "{"
        for elements in self.getSongs():
            if elements == self.getSongs()[-1]:
                test_str = test_str + elements.__str__()
            else:
                test_str = test_str + elements.__str__() + "|"
        return test_str

    def all_likes(self):
        counter = 0
        for elements in self.__songs:
            counter = counter + elements.getLikes()

        return counter



